let preçoInicial = parseFloat (prompt("Informe um valor inicial para o produto"));
let preçoFinal = parseFloat (prompt("Informe um valor final para o produto"));
let valorFinal = ((preçoInicial-preçoFinal)/preçoInicial*100);
alert (`O desconto do produto foi de ${valorFinal}%`);