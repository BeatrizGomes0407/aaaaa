let pesoKg = parseFloat (prompt("Informe o seu peso aqui"));
let pesoMaior = (pesoKg*0.15);
let pesoMenor = (pesoKg*0.20);
let pesoMaiorFinal = (pesoMaior+pesoKg);
let pesoMenorFinal = (pesoKg-pesoMenor);
alert (`O seu novo peso caso você engorde 15% será ${pesoMaiorFinal} em kg`);
alert (`O seu novo peso caso você emagreça 20% será ${pesoMenorFinal} em kg`);