let gado = parseFloat (prompt("Informe quantas cabeças de gado há"));
let gadoHerdeiros = parseFloat (prompt("Informe a quantidade de herdeiros das cabeças de gado"));
let gadoTotal = (gado-(gado*0.15));
let divisaoHerdeiros = (gadoTotal/gadoHerdeiros);
alert (`O fazendeiro, antes de falecer, doou 15% das cabeças de gado para a caridade, dando um total de ${gadoTotal}`);
alert (`Cada herdeiro receberá ${divisaoHerdeiros} cabeças de gado para cada`);