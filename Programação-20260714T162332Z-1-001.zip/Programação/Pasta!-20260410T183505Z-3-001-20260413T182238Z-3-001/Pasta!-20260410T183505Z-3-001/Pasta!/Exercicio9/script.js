let preçoProduto = parseFloat (prompt("Informe um preço para o produto que sofrerá um desconto de 5%"));
let preçoDesconto = (5);
let valorFinal = ((preçoProduto*preçoDesconto)/100);
alert (`O preço final do produto é de R$ ${preçoProduto-valorFinal}`);
alert (`O desconto que esse produto sofreu foi de R$ ${valorFinal.toFixed(2)}`);