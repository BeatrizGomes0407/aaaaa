let horasExtras = parseFloat(prompt("Quais foram as suas horas extras realizadas?"))
let horasTrabalhadas = parseFloat(prompt("Quais são as suas horas trabalhadas no mês?"));
let funcinario = parseInt(prompt("Qual tipo de funcionario você é? (1, 2 ou 3)"));
switch (funcinario) {
    case 1:
        let horaNormal1 = horasTrabalhadas * 25;
        let horaExtra1 = horasExtras * 35;
        let salario = horaNormal1 + horaExtra1;
        alert(`Sua categoria é: Programador Júnior, a sua quantidade de horas trabalhadas é ${horasTrabalhadas},a quantidade de suas horas extras são ${horasExtras} o valor da sua hora normal é ${horaNormal1}, o valor da sua hora extra é de ${horaExtra1} e o seu salário bruto será de ${salario}`);
        break;
    case 2:
        let horaNormal1 = horasTrabalhadas * 25;
        let horaExtra1 = horasExtras * 35;
        let salario = horaNormal1 + horaExtra1;
        alert(`Sua categoria é: Programador Júnior, a sua quantidade de horas trabalhadas é ${horasTrabalhadas},a quantidade de suas horas extras são ${horasExtras} o valor da sua hora normal é ${horaNormal1}, o valor da sua hora extra é de ${horaExtra1} e o seu salário bruto será de ${salario}`);
        break;
    case 3:
        let horaNormal1 = horasTrabalhadas * 25;
        let horaExtra1 = horasExtras * 35;
        let salario = horaNormal1 + horaExtra1;
        alert(`Sua categoria é: Programador Júnior, a sua quantidade de horas trabalhadas é ${horasTrabalhadas},a quantidade de suas horas extras são ${horasExtras} o valor da sua hora normal é ${horaNormal1}, o valor da sua hora extra é de ${horaExtra1} e o seu salário bruto será de ${salario}`);
        break;
    default:
        alert("Tipo de média inválida.");
        break;
}