let valorCompra = parseFloat(prompt(`Insira o valor total bruto das compras (em R$)`));
let fidelidade = (prompt(`Digite o nível de fidelidade (escreva "Bronze", "Prata" ou "Ouro")`));
let cupom = (prompt(`O cupom de desconto é valido? (digite sim ou não)`));
if(fidelidade == "Ouro"){
    let desconto1 = (valorCompra - (valorCompra*0.15));
    if(desconto1 >= 150){
        alert(`O seu frete é grátis`)
    } else (desconto1 < 150)
    {
        alert(`O seu frete custa R$10,00`)
    }
} else if(fidelidade == "Prata" && cupom == "sim"){
    let desconto2 = (valorCompra - (valorCompra*0.10));
} else if(fidelidade == "Prata" && cupom == "não"){
    let desconto3 = (valorCompra - (valorCompra*0.05))
} else if(valorCompra > 250){
    alert(`O seu frete é grátis`)
} else if(valorCompra < 250){
    alert(`O valor do seu frete é de R$20`)
        alert(`O valor do frete é 20R$, o valor bruto é ${valorCompra} e com o desconto fica ${desconto3}`)
} else if(fidelidade == "Bronze"){
    if (cupom == "sim"){
        let desconto4 = (valorCompra - (valorCompra*0.05));
        alert(`O valor do frete é 30R$, o valor bruto é ${valorCompra} e com o desconto fica ${desconto4}`)
    } else (cupom == "não")
    {
        alert(`O valor do frete é 30R$, o valor bruto é ${valorCompra} e com o desconto fica ${valorCompra}`)
    }
}