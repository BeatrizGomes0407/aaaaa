let idade = parseInt(prompt(`Insira a idade do motorista`));
let acidente = parseInt(prompt(`Insira um valor para o histórico de acidentes nos últimos 3 anos`));
let veiculo = (prompt(`Possui freios ABS e Airbag? (digite sim ou não)`));
if(idade < 25 || acidente > 2){
    alert(`Perfil de Risco Alto.`);
    if (veiculo == "sim"){
        alert(`O seu valor mensal é de R$450,00`);
    } else (veiculo == "não")
    {
        alert(`o seu valor mensal é de R$550,00`);
    }
}else if(idade > 25 && (acidente == 1 || acidente == 2) || 
        (idade < 25 && acidente == 0)){
    alert(`Perfil de Risco Moderado`);
        if (veiculo == "não"){
        alert(`O seu valor mensal é de R$300,00`);
        }else (veiculo == "sim")
        {
        alert(`O seu valor mensal é de R$270,00`);
    }
} else (idade > 25 && acidente == 0)
{
    alert(`Perfil de Risco Baixo (Excelente Condutor) e o seu valor mensal é de R$180,00`);
}