let media = parseFloat(prompt(`Informe o valor da sua media final`));
let renda = parseFloat(prompt(`Informe o valor da sua renda mensal`));
if(media >= 9 && renda <= 2000){
    alert(`Você ganhou 100% de bolsa`);
}else if(media >= 8 && renda <= 3500){
    alert(`Você ganhou 50% de bolsa`);
}else if(media >= 7 && renda <= 5000)
{
    alert(`Você ganhou 25% de bolsa`);
}else{
    alert(`Você não ganhou nenhum % de bolsa`);
}