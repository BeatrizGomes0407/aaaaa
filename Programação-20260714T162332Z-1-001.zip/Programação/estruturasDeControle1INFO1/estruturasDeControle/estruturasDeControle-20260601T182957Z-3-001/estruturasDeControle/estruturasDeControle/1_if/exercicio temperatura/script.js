let temperatura = parseFloat(prompt(`Insira um valor para a temperatura em graus C`));
if(temperatura == 20 || 21 || 22|| 23 || 24){
    alert(`A temperatura está agradável!`);
}else if(temperatura < 20){
    alert(`A temperatura está fria`);
}else(temperaturea > 24);{
    alert(`A temperatura está quente`)
}