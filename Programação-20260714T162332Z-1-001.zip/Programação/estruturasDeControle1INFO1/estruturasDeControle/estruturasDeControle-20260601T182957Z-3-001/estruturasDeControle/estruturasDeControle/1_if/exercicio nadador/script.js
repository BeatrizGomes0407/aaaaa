let idade = parseInt(prompt(`Insira a sua idade`));

if (idade <= 12) {
    alert(`A sua categoria é Infantil`);
} else if (idade >= 13 && idade <= 17) {
    alert(`A sua categoria é Juvenil`);
} else {
    alert(`A sua categoria é Adulto`);
}