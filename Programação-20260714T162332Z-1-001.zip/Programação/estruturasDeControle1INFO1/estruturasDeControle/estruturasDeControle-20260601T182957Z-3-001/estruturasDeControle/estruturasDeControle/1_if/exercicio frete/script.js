let produtoPeso = parseFloat(prompt(`Insira um valor para o peso do produto (em kg)`));

if (produtoPeso <= 5) {
    alert(`O valor do frete é de R$20`);
} else if (produtoPeso < 20) {
    alert(`O valor do frete é de R$50`);
} else {
    alert(`O valor do frete é de R$100`);
}
