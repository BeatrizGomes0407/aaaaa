const usuario1 = BeatrizG;
const senha1 = 1234;
let usuario2 = (prompt(`Insira o nome de usuário da sua conta`));
let senha2 = (prompt(`Insira a senha da sua conta`));
if(usuario1 == usuario2 && senha1 == senha2){
    alert(`Você está liberado!`);
}else if(usuario1 != usuario2 && senha1 == senha2){
    alert(`Usuário incorreto!`);
}else if(usuario1 == usuario2 && senha1 != senha2){
    alert(`Senha incorreta!`);
}