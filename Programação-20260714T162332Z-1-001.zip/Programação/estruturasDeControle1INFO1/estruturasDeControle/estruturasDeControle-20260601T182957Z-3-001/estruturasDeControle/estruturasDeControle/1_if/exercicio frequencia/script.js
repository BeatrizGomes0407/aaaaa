let nota = parseFloat(prompt(`Insira um valor para a sua nota`));
let frequencia = parseFloat(prompt(`Insira um valor para a sua frequência`));
if(nota>=7 && frequencia>=70){
    alert(`Você está aprovado!`);
}else (nota<=7 && frequencia<=70);{
    alert(`Você está reprovado!!`);
}