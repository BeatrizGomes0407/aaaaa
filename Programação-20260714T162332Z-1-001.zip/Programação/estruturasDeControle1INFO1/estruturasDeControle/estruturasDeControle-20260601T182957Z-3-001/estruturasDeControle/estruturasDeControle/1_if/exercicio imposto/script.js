let salario = parseFloat(prompt(`Insira um valor para o seu salario`));

if (salario <= 2500) {
    alert(`Isento (sem imposto de renda)`);
} else if (salario <= 5000) {
    let imposto1 = salario * 0.15;
    alert(`O valor do imposto a ser pago é de ${imposto1}`);
} else {
    let imposto2 = salario * 0.27;
    alert(`O valor do imposto a ser pago é de ${imposto2}`);
}
