let nota1 = parseFloat(prompt(`Informe a sua primeira nota`));
let nota2 = parseFloat(prompt(`Informe a sua segunda nota`));
let media = ((nota1 + nota2) / 2);
if(media >= 7){
    alert(`Você está aprovado, a sua média é ${media}`);
}else if(media > 5 && media <= 6.9){
    alert(`Você está de recuperação, a sua média é ${media}`);
}else
{
    alert(`Você está reprovado, a sua média é ${media}`);
}