let a = parseFloat(prompt(`Insira um valor para a primeira medida do triângulo`));
let b = parseFloat(prompt(`Insira um valor para a segunda medida do triângulo`));
let c = parseFloat(prompt(`Insira um valor para a terceira medida do triângulo`));
if (a + b > c && a + c > b && b + c > a) {
    alert(`Vai formar um triângulo`);
}else {
    alert(`Não vai formar um triângulo`);
}