let consumoMensal = parseFloat(prompt(`Informe o valor para o consumo mensal da água (em m cúbicos)`));
if(consumoMensal <= 10){
    alert(`O valor da cobrança é de 30RS`);
}else if(consumoMensal <= 25){
    alert(`O valor da cobrança é de 50RS`);
}else
{
    alert(`O valor da cobrança é de 80RS`);
}