let medida1 = parseFloat(prompt(`Insira um valor para a primeira medida do triângulo`));
let medida2 = parseFloat(prompt(`Insira um valor para a segunda medida do triângulo`));
let medida3 = parseFloat(prompt(`Insira um valor para a terceira medida do triângulo`));
if(medida1 == medida2 && medida1 == medida3){
    alert(`O triângulo é equilátero`);
}else if(medida1 == medida2 || medida1 == medida3 || medida2 == medida3){
    alert(`O triãngulo é isósceles`);
}else(medida1 != medida2 & medida2 != medida3);{
    alert(`O triângulo é escaleno`);
}