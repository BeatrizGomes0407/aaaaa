let numero1 = parseFloat(prompt(`Insira um valor para o primeiro número`));
let numero2 = parseFloat(prompt(`Insira um valor para o segundo número`));
let operacao = parseFloat(prompt(`Insira qual operação você vai usar(+, -, *, /)`))
if(operacao === "+"){
    let soma = (numero1+numero2);
    alert(`A soma da sua operação é ${soma}`)
}else if(operacao === "-"){
    let subtração = (numero1-numero2);
    alert(`A subtração da sua operação é ${subtração}`)
}else if(operacao === "*"){
    let multiplicação = (numero1*numero2);
    alert(`A multiplicação da sua operação é ${multiplicação}`)
}else(operacao === "/");{
    let divisão = (numero1/numero2);
    alert(`A divisão da sua operação é ${divisão}`)
}