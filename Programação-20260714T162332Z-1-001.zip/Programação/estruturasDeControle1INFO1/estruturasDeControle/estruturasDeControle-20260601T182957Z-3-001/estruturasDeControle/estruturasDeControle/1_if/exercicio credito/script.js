let saldo = parseFloat(prompt(`Informe o seu saldo`));
if(saldo <= 500){
    alert(`Você não ganhou nenhum crédito`);
}else if(saldo <= 1000){
    let credito1 = (saldo + (saldo*0.3));
    alert(`Você ganhou um crédito de 30%, seu saldo médio é de ${credito}`);
}else(saldo > 1000)
{
    let credito2 = (saldo + (saldo*0.5));
    alert(`Você ganhou um crédito de 50%, seu saldo médio é de ${credito2}`);
}