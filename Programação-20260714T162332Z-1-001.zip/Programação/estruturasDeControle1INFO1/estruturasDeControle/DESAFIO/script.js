// Entrada 
let areaPintura = parseFloat(prompt(`Indique um valor para a área total a ser pintada (em m quadrados)`));
let rendimentoTinta = parseFloat(prompt(`Indique um valor para o rendimento da tinta (em m quadrados por litro)`));
let volumetriaLata = parseFloat(prompt(`Indique um valor para a volumetria da lata de tinta (em litros)`));
let precoLata = parseFloat(prompt(`Indique um valor para o preço unitário da lata de tinta`));
let horasPintura = parseFloat(prompt(`Indique um valor para as horas estimadas para a execução do serviço`));
let quantPintores = parseFloat(prompt(`Indique um valor para a quantidade de pintores na equipe`));
let valorHoraPintor = parseFloat(prompt(`Indique um valor da hora cobrado pelo pintor`));
let valorReservado = parseFloat(prompt(`Indique um valor para para o orçamento máximo disponível pela família`));

// Cálculos de material
let litragemTotal = Math.ceil(areaPintura / rendimentoTinta);
let quantLatasTinta = Math.ceil(litragemTotal / volumetriaLata);
let tintaCusto = (quantLatasTinta * precoLata);

// Cálculos mão de obra
let custoEquipe = horasPintura * quantPintores * valorHoraPintor;

// Análise financeira
let custoTotal = (tintaCusto + custoEquipe);
if(valorReservado >= custoTotal){
    let desconto = custoTotal - (custoTotal*0.05);
    let saldoFinal = (valorReservado - desconto);
    alert(`O seu saldo final será de ${saldoFinal} Reais, vocẽ deve pagar á vista`);
}else if(valorReservado < custoTotal){
    if(custoTotal >= valorReservado && (valorReservado - (valorReservado*0.5))){
        alert(`Você deveria parcelar 4 vezes sem juros`)
    } else if(custoTotal >= (custoTotal - (custoTotal*0.03)) && (custoTotal - (custoTotal*0.049)) <= valorReservado){
        alert(`Você deveria parcelar em 3 vezes sem juros`);
    }else(custoTotal <= (custoTotal - (custoTotal*0.03)))
    {
        alert(`Você deveria fazer o parcelamento padrão em 2 vezes sem juros`);
    }
}

// Saída de dados
alert(`
    A quantidade de latas de tinta foram ${quantLatasTinta.toFixed(2)} e o custo total do material foi de ${tintaCusto.toFixed(2)}. \n
    O custo total da mão de obra foi de ${custoEquipe.toFixed(2)}. \n
    O custo total bruto da pintura foi de ${custoTotal.toFixed(2)}
    `)