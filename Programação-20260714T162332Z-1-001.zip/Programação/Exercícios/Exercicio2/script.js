let A = 10;
let B = 5;
let C = A + B;

console.log(C);
alert(`O valor da soma de A e B é ${C}`);
