let constituição = `Instituto Federal de Araquari`;
let curso = `Informatica para a internet`;
let semestre = `primeiro`;

console.log(constituição);
console.log(curso);
console.log(semestre);

console.log(
  `Estudo no ${constituição}, e realizo o curso de ${curso} e estou no ${semestre} semestre`,
);
