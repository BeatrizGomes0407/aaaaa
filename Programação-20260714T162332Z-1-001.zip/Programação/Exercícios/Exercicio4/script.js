let número = prompt(`Digite um número`);
console.log(número * 2);
